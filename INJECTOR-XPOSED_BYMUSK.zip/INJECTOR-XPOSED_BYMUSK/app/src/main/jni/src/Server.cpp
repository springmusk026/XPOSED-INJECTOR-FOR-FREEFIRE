#include <pthread.h>
#include <jni.h>
#include <stdio.h>
#include <wchar.h>
#include <src/Substrate/SubstrateHook.h>
#include "src/Unity/Quaternion.hpp"
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Unity.h"
#include "src/Unity/Hook.h"
#include "src/Unity/Global.h"
#include "src/Unity/Color.hpp"
#include "src/Unity/Rect.hpp"
#include "src/Unity/ESP.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include <cstdio>
#include <cstdlib>
#include <fcntl.h>
#include <unistd.h>
#include <cmath>
#include <dirent.h>
#include <thread>
#include <sys/uio.h>
#include <sys/un.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
# define getRealOffset(offset) AgetAbsoluteAddress("libil2cpp.so", offset)

# define HOOK(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)

using namespace std;



bool aimAuto = false;
bool aimAtirar = false;
bool aimMirar = false;
bool aimAgachar = false;
bool espNames = false;
bool espAlerta = false;
bool espGranada = false;

bool enableFov = true;

int enemyCountAround = 0;
int botCountAround = 0;

int counterFPS;
bool nightmode = false;
bool verify = false;
bool active = true;
bool launched = false;
bool TelecarPro = false;
bool EspFire = false;
bool telekill = false;
float aimFov = 360.0f;
bool fly = false;
bool under = false;
bool medkitrun = false;
bool RG = false;
Vector3 GetHeadPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::HeadTF));
}

Vector3 GetHipPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::HipTF));
}

Vector3 GetToePosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::ToeTF));
}
Vector3 GetDedoSPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::HeadTF));
}

Vector3 GetPeDPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::PeD));
}

Vector3 GetPeSPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::PeS));
}

Vector3 getPositionRShoulder(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::RightShoulder));
}
Vector3 getPositionLShoulder(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::LeftShoulder));
}

Vector3 getPositionLJ(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::LeftLJ));
}

Vector3 getPositionRJ(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::RightLJ));
}
Vector3 getPositionRightHand(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::RightHand));
}

Vector3 getPositionLeftHand(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Parts::LeftHand));

}
	          
   Vector3 CameraMain(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Controller::MainCameraTransform));
}



void *GetClosestEnemy(void *match) {
    if(!match) {
        return NULL;
    }
	
    float shortestDistance = 99999;
    float maxAngle = aimFov;
	
    void* closestEnemy = NULL;
    void* LocalPlayer = GetLocalPlayer(match);
	
    if(LocalPlayer != NULL && !get_IsDieing(LocalPlayer)) {
       
		monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)match + Controller::Dictionary);
		for(int u = 0; u < players->getNumValues(); u++) {
            void* Player = players->getValues()[u];
           
			if(Player != NULL && !get_isLocalTeam(Player) && !get_IsDieing(Player) && get_isVisible(Player) && get_MaxHP(Player)) {
			  
                Vector3 PlayerPos = GetHipPosition(Player);
                Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
				
                if(enableFov) {
                    Vector3 targetDir = Vector3::Normalized(PlayerPos - LocalPlayerPos);
                    float angle = Vector3::Angle(targetDir, GetForward(Component_GetTransform(Camera_main()))) * 100.0;
                   
					if(angle <= maxAngle) {
                        if(angle < shortestDistance) {
                            shortestDistance = angle;
                            closestEnemy = Player;
                        }
                    }
                } else {
                    if(maxAngle < shortestDistance) {
                        shortestDistance = maxAngle;
                        closestEnemy = Player;
                    }
                }
            }
        }
    }
	return closestEnemy;
}
void (*LateUpdate)(void *componentPlayer);

void* UpdateCanvas = nullptr;
void get_CanvasUpdate(void* player) {
	UpdateCanvas = player;
}

void *fakeEnemy;
void _LateUpdate(void *player) {
	
	if(player != nullptr) {
		void *local_player = Current_Local_Player();
       
        if (local_player == NULL){
            local_player = GetLocalPlayerOrObServer();
        }
      
        if (local_player != NULL){
            void *current_match = Curent_Match();
         
            if (current_match != NULL) {
                
                
                    
                
                
                void *fakeCamPlayer = get_MyFollowCamera(local_player);
                void *fakeCamEnemy = get_MyFollowCamera(player);
             
                if (fakeCamPlayer != NULL && fakeCamEnemy != NULL){
                    void *fakeCamPlayerTF = Component_GetTransform(fakeCamPlayer);
                    void *fakeCamEnemyTF = Component_GetTransform(player);
                
                    if (fakeCamPlayerTF != NULL && fakeCamEnemyTF != NULL) {
                        Vector3 fakeCamPlayerPos = Transform_INTERNAL_GetPosition(fakeCamPlayerTF);
                        Vector3 fakeCamEnemyPos = Transform_INTERNAL_GetPosition(fakeCamEnemyTF);
                        float distance = Vector3::Distance(fakeCamPlayerPos, fakeCamEnemyPos);
                     
                        if (player != local_player) {
                          
                            if (distance < 1.6f) {
                                fakeEnemy = player;
                            }
                        }
                    }
                }
	        }
        }
		
		void* Match = Curent_Match(); {
            void* LocalPlayer = GetLocalPlayer(Match);
            
            if(LocalPlayer) {
				void* closestEnemy = GetClosestEnemy(Match);
				
			if(closestEnemy) {
                    
					Vector3 EnemyLocation = GetHeadPosition(closestEnemy);
					Vector3 PlayerLocation = CameraMain(LocalPlayer);
					Vector3 CenterWS = GetAttackableCenterWS(LocalPlayer);
					
					Quaternion PlayerLook = GetRotationToLocation(GetHeadPosition(closestEnemy), 0.1f, PlayerLocation);
					Quaternion PlayerLook2 = GetRotationToLocation(GetHipPosition(closestEnemy), 0.1f, PlayerLocation);
					Quaternion PlayerLook3 = GetRotationToLocation(GetToePosition(closestEnemy), 0.1f, PlayerLocation);
					
					float distance = Vector3::Distance(CenterWS, EnemyLocation);
					
					Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
					Vector3  PlayerPos    = GetHeadPosition(closestEnemy);
					
					bool scope = get_IsSighting(LocalPlayer);
					bool agachado = get_IsCrouching(LocalPlayer);
					bool firing = get_IsFiring(LocalPlayer);
					bool caido = get_IsDieing(closestEnemy);
					
					
					
					bool dirigindo = IsDriver(LocalPlayer);
  if (TelecarPro && distance < 105.0f && dirigindo) {

    // INICIO DO TELEPORTE
    void *_TeleCarTP = Component_GetTransform(closestEnemy);
    if (_TeleCarTP != NULL) {
		
        Vector3 TeleCarTP =
                Transform_INTERNAL_GetPosition(_TeleCarTP) - (GetForward(_TeleCarTP) * 0.0f);

        void* LocalCar = GetLocalCar(LocalPlayer);
        if (LocalCar != NULL) {

            Transform_INTERNAL_SetPosition(Component_GetTransform(LocalCar), Vvector3(TeleCarTP.X, TeleCarTP.Y + 3.0f, TeleCarTP.Z ));

        }

    }
    // FIM DO TELEPORTE


}
// TELEPORTE CAR

        if (telekill) {
            void *_MountTF = Component_GetTransform(closestEnemy);
            if (_MountTF != NULL) {
                Vector3 MountTF =
                        Transform_INTERNAL_GetPosition(_MountTF) -
                        (GetForward(_MountTF) * 0.0f);
                Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer),
                                               Vvector3(MountTF.X, MountTF.Y + 2.0f,
                                                        MountTF.Z));
            }
        }

                        if (EspFire ) {
                            void *imo = get_imo(LocalPlayer);
                            if (imo != NULL ) {
                                set_esp(imo, CenterWS, PlayerPos);
                                 }
                        }


                                 if (espNames) {
                
					monoString* count = FormatCount((enemyCountAround + botCountAround)-1);
				
					ShowDynamicPopupMessage(count);
					
					           }

                    int tmpEnemyCountAround = 0;
                    int tmpBotCountAround = 0;

                    monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t *, void **> **) ((long) Match + 0x44);
                    for (int u = 0; u < players->getNumValues(); u++) {
                    void *closestEnemy = players->getValues()[u];

                    enemyCountAround = tmpEnemyCountAround;
                    botCountAround = tmpBotCountAround;

                    if (closestEnemy != NULL && closestEnemy != LocalPlayer && !get_isLocalTeam(closestEnemy) && get_isVisible(closestEnemy) && get_isAlive(closestEnemy)) {

                    if (closestEnemy != NULL) {
                    bool isBot = *(bool*)((uintptr_t)closestEnemy +      Condition::IsClientBot);
                    if (isBot) {
                    ++tmpBotCountAround;
                    } else {
                    ++tmpEnemyCountAround;
                    }
                 }
              }
            
         }
		     
						
					
					
					if (espNames) {
						          bool ind = *(bool *) (
                                    (uintptr_t) closestEnemy +
                                         Condition::IsClientBot);
                            void *ui = CurrentUIScene();

                            if (ui != NULL) {
                                if (ind) {
                                    monoString *nick = get_NickName(closestEnemy);
                                    monoString *distances = U3DStrFormat(distance);
                                    AddTeammateHud(ui, nick, distances);
                                } else {
                                    monoString *nick = get_NickName(closestEnemy);
                                    monoString *distances = U3DStrFormat2(distance);
                                    AddTeammateHud(ui, nick, distances);
                                }
                            }
                        }

					
			       		if(espGranada) {
				              GrenadeLine_DrawLine(Grenade2, LocalPlayerPos, LocalPlayerPos,
                                                 Vector3(0, 1, 0) * 0.6);
                            ((void (*)(void *, Color)) getRealOffset(Controller::Set_StartColor))(Render2,
                                                                                 Color::Green());
                            ((void (*)(void *, Color)) getRealOffset(Controller::Set_EndColor))(Render2,
                                                                                 Color::Blue());
					            if (Render2) {
                                LineRenderer_Set_PositionCount(Render2, 0x2);
                                LineRenderer_SetPosition(Render2, 0, LocalPlayerPos);
                                LineRenderer_SetPosition(Render2, 1, PlayerPos);
                            }
                        }
					

					
		        	if (aimAuto) {
						set_aim(LocalPlayer, PlayerLook);
					}
               
					if (scope && aimMirar) {
						set_aim(LocalPlayer, PlayerLook);
					}
					
					if (agachado && aimAgachar) {
						set_aim(LocalPlayer, PlayerLook);
					}
						
					if (firing && aimAtirar) {
						set_aim(LocalPlayer, PlayerLook);
					}
				}
			}
		}
	}
    get_CanvasUpdate(player);
    LateUpdate(player);
	}




static bool isEspReady() {
	return false;
}

void (*DoUpdate)(void* Counter); // COW.FpsCounter

void _DoUpdate(void* Counter) {
    DoUpdate(Counter);
    if (Counter) {
        counterFPS =  *(int*)((uint64_t)Counter + 0x14);
    }
}
bool (*DeleteGuest)(void* _this);
bool _DeleteGuest(void* _this) {
    if(RG){
      return true;
    }
    return DeleteGuest(_this);
}


void *readFile(void *){						
      LOGI("readFile");

		bool cp;

            while (1){
            FILE *f = NULL;
            char line[200];
            f = fopen("/storage/emulated/0/musk", "r");
            while(fgets(line,199,f) != NULL){
                LOGI("line = %s", line);

                if (strstr(line, "aimAuto_on") || strstr(line, " aimAuto_on")){
                   
                      aimAuto = true; 
                }else if(strstr(line, "aimAuto_off") || strstr(line, " aimAuto_off")){
                   aimAuto = false;
				   
                }

				if (strstr(line, "aimAtirar_on") || strstr(line, " aimAuto_on")){
                   
                      aimAtirar = true; 
                }else if(strstr(line, "aimAtirar_off") || strstr(line, " aimAuto_off")){
                   aimAtirar = false;
				   
                }

				if (strstr(line, "aimMirar_on") || strstr(line, " aimMirar_on")){
                      aimMirar = true; 
                }else if(strstr(line, "aimMirar_off") || strstr(line, " aimMirar_off")){
                   aimMirar = false;
				         }
				
				if (strstr(line, "aimAgachar_on") || strstr(line, " aimAgachar_on")){
                     aimAgachar = true; 
                }else if(strstr(line, "aimAgachar_off") || strstr(line, " aimAgachar_off")){
                   aimAgachar = false;
				       }
				
				if (strstr(line, "espNames_on") || strstr(line, " espNames_on")){
                       espNames = true; 
                }else if(strstr(line, "espNames_off") || strstr(line, " espNames_off")){
                   espNames = false;
				     }
				
				if (strstr(line, "espAlerta_on") || strstr(line, " espAlerta_on")){
                       EspFire = true; 
                }else if(strstr(line, "espAlerta_off") || strstr(line, " espAlerta_off")){
                   EspFire = false;
	            }
				
				if (strstr(line, "espGranada_on") || strstr(line, " espGranada_on")){
                       espGranada = true; 
                }else if(strstr(line, "espGranada_off") || strstr(line, " espGranada_off")){
                   espGranada = false;
	            }
				
				if (strstr(line, "RG_on") || strstr(line, " RG_on")){
                       RG = true; 
                }else if(strstr(line, "RG_off") || strstr(line, " RG_off")){
                   RG = false;
	            }
				
				if (strstr(line, "telekill_on") || strstr(line, " telekill_on")){
                       telekill = true; 
                }else if(strstr(line, "telekill_off") || strstr(line, " telekill_off")){
                   telekill = false;
	            }
				
				if (strstr(line, "TelecarPro_on") || strstr(line, " TelecarPro_on")){
                       TelecarPro = true; 
                }else if(strstr(line, "TelecarPro_off") || strstr(line, " TelecarPro_off")){
                   TelecarPro = false;
	            }
				
				






            }



            sleep(1);
    }
    return NULL;
}
bool(*AntiCrash)(void* _this);
bool _AntiCrash(void* _this) {
    return false;
}

const char* name = "libil2cpp.so";

void *hack_thread(void *) {
    while (true) {
        if (getRealOffset(0) != 0) {
			HOOK(MainOffsets::Update, _LateUpdate, LateUpdate); // GameStartUp Update
    MSHookFunction((void *)getRealOffset(MainOffsets::GrenadeLine_Update), (void *)GrenadeLine_Update, (void **)&_GrenadeLine_Update);
 HOOK(0x120D0F0, _DeleteGuest, DeleteGuest);
           pthread_exit(nullptr);
        }
    }
    return nullptr;
}


extern "C"
__attribute__((constructor))
void OnCreate() {
    if (!launched) {
        launched = true;
     
		FILE *f = NULL;
        f = fopen("/storage/emulated/0/musk", "r");
	    if (f == NULL)
        fopen("/storage/emulated/0/musk", "w+");

		
		
		pthread_t ptid;
		pthread_create(&ptid, nullptr, hack_thread, nullptr);
        pthread_t ptid2;
         pthread_create(&ptid2, NULL, readFile, NULL);
		
		 
		}
}

