#include <pthread.h>
#include <jni.h>
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Vector2.hpp"
#include "src/Unity/Unity.h"
#include "src/Unity/ESP.h"
#include "Includes/Logger.h"
#include "Menu.h"
#include "str.h"
#include <iostream>
#include <fstream>
using namespace std;

jobjectArray getFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    //Toasts added here so it's harder to remove it

    const char *features[] = {
                     "CT_A I M B O T",//0
            
            "TG_AIMBOT AUTO",//1
            
            "TG_AIMBOT FIRE",//2
            
            "TG_AIMBOT SCOPE",//3
           
            "TG_AIMBOT CROUCH",//4
            
            "SB_AIM FOV_0_360_x",//5
			
			"CT_ESP MATERIAL",//6
			
            "TG_ESP INFO",//7
            
            "TG_ESP FIRE",//8
			
			"TG_ESP GRENADE",//9
			
			"CT_TELEKILL",//10
			
			"TG_TELEKILL CAR",//11
			
			"TG_TELEKILL PLAYER",//12
			
			"TG_Reset Guest",//13
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}
bool aimAuto;
bool aimAtirar;
bool aimMirar ;
bool aimAgachar ;
bool espNames ;
bool espAlerta ;
bool espGranada ;

bool enableFov ;
bool RG ;
float aimFov = 0.0f;
bool TelecarPro ;
bool telekill ;
void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
        
        case 0:
            aimAuto = boolean;
			if(aimAuto){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "aimAuto_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "aimAuto_off";
            myfile.close();
				
			}   break;
            
        case 1:
            aimAtirar = boolean;
			if(aimAtirar){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "aimAtirar_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "aimAtirar_off";
            myfile.close();
				
			}  break;
            
        case 2:
            aimMirar = boolean;
			if(aimMirar){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "aimMirar_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "aimMirar_off";
            myfile.close();
				
			}   break;
            
        case 3:
            aimAgachar = boolean;
			if(aimAgachar){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "aimAgachar_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "aimAgachar_off";
            myfile.close();
				
			}   break;
            
        case 4:
            aimFov = value;
            if(value == 0) {
				aimFov = 0.0f;
			}
            break;
        
        case 5:
            espNames = boolean;
			if(espNames){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "espNames_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "espNames_off";
            myfile.close();
				
			}   break;
            
        case 6:
            espAlerta = boolean;
			if(espAlerta){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "espAlerta_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "espAlerta_off";
            myfile.close();
				
			}   break;
			
		case 7:
			espGranada = boolean;
	     	if(espGranada){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "espGranada_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "espGranada_off";
            myfile.close();
				
			}
			break;
			
		case 8:
			TelecarPro = boolean;
	     	if(TelecarPro){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "TelecarPro_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "TelecarPro_off";
            myfile.close();
				
			}
			break;
			
		case 9:
			telekill = boolean;
	     	if(telekill){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "telekill_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "telekill_off";
            myfile.close();
				
			}
			break;
			
		
			
			
		case 10:
			RG = boolean;
	     	if(RG){
			ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "RG_on";
            myfile.close();
			}else{
		    ofstream myfile;
            myfile.open ("/storage/emulated/0/musk");
            myfile << "RG_off";
            myfile.close();
				
			}
			break;	
    }
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    // Register your class native methods. Build and ecompile the app and see the signature
    // This is to hide function names from disassembler
    // See more: https://developer.android.com/training/articles/perf-jni#native-libraries

    //Your menu class
    jclass c = globalEnv->FindClass("com/android/support/Menu");
    if (c != nullptr){
        static const JNINativeMethod menuMethods[] = {
              {("Icon"), ("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
              {("IconWebViewData"),  ("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
              {("setHeadingText"),  ("(Landroid/widget/TextView;)V"), reinterpret_cast<void *>(setHeadingText)},
              {("setTitleText"),  ("(Landroid/widget/TextView;)V"), reinterpret_cast<void *>(setTitleText)},
              {("settingsList"),  ("()[Ljava/lang/String;"), reinterpret_cast<void *>(settingsList)},
              {("getFeatureList"),  ("()[Ljava/lang/String;"), reinterpret_cast<void *>(getFeatureList)},
        };

        int mm = globalEnv->RegisterNatives(c, menuMethods, sizeof(menuMethods) / sizeof(JNINativeMethod));
        if (mm != JNI_OK) {
            LOGE(("Menu methods error"));
            return mm;
        }
    }
    else{
        LOGE(("JNI error"));
        return JNI_ERR;
    }

    jclass p = globalEnv->FindClass( ("com/android/support/Preferences"));
    if (p != nullptr){
        static const JNINativeMethod prefmethods[] = {
                { ("Changes"), ("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
        };

        int pm = globalEnv->RegisterNatives(p, prefmethods, sizeof(prefmethods) / sizeof(JNINativeMethod));
        if (pm != JNI_OK){
            LOGE(("Preferences methods error"));
            return pm;
        }
    }
    else{
        LOGE(("JNI error"));
        return JNI_ERR;
    }

    return JNI_VERSION_1_6;
}


__attribute__((constructor))
void initializer() {
    LOGI("começou");
	
    FILE *f = NULL;
    f = fopen("/storage/emulated/0/musk", "r");
	if (f == NULL)
        fopen("/storage/emulated/0/musk", "w+");

	
}

