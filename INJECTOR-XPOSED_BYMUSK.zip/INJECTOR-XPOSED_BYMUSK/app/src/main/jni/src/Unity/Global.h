#ifndef OFFSETS_H
#define OFFSETS_H

namespace MainOffsets {
    enum MainOffsets {
     
		Update = 0x1195088,
		
		GrenadeLine_Update = 0x115c1ec ,
		
	    Curent_Match = 0xab312c,
	
		Camera_main = 0x2ba19bc,
		
		WorldToScreenPoint = 0x2ba12cc,
		
    };
}
namespace Controller {
    enum Controller {
     
		MainCameraTransform = 0x6C ,
		
		Dictionary = 0x44,
		
		GetWeaponType = 0x8f8544,
		
		GrenadeLine_isVisible = 0xC,
		
		GrenadeLine_m_GrenadeLine = 0x10,
		
	    LineRenderer_Set_PositionCount = 0x2b37f10,
		
		LineRenderer_SetPosition = 0x2b37fbc,
    
		GrenadeLine_DrawLine = 0x115c53c,
		
		Set_StartColor = 0x2b37d30,
		
		Set_EndColor = 0x2b37dd4,
		
		get_imo = 0x8ab8ec,
		
		set_esp = 0x1302a60,
		
		set_aim = 0x8afe3c,
		
        GetForward = 0x2b627a8,
		
		GetLocarCar = 0x8b057c,
		
		IsDriver = 0x8935b8,
		
		
		
    };
}
namespace Parts {
    enum Parts {
     
     HeadTF = 0x1E8,
	
	 HipTF = 0x1EC,
	
	 HandTF = 0x1E4,
	
	 EyeTF = 0x1F0,

	 ToeTF = 0x1FC,
	
	 PeS = 0x210,
	
	 PeD = 0x20C,
	
	 RightShoulder = 0x21C,
	
	 LeftShoulder = 0x218,
	
	 RightHand =0x1E4,
	
	 LeftHand = 0x214,
	
	 RightLJ =0x208,
	
	 LeftLJ = 0x208,
    };
}

namespace Condition {
    enum Condition {
     
	 IsClientBot = 0xF0,
	 
     get_isAlive = 0x9007c0,
	 
	 get_IsSighting = 0x88f168,
	 
	 get_isLocalTeam = 0x8b85f4,
	 
	 get_isVisible = 0x8b1ad8,
	 
	 get_IsDieing = 0x88ac18,
	 
	 GetAttackableCenterWS = 0x8aea78,
	 
	 get_NickName = 0x8aefdc,
	 
	 get_CurHP = 0x8e690c,
	 
	 get_MaxHP = 0x8e69e8,
	 
	 Current_Local_Player = 0xab3450,
	 
	 GetLocalPlayerOrObServer = 0xab3c84,
	 
	 get_IsFiring = 0x88f11c,
	 
	 GetLocalPlayer = 0xd3800c,
	 
	 GetPlayerDead = 0x8b035c,
	 
	 get_MyFollowCamera = 0x8af6b8,
	 
	 get_IsCrouching = 0x88abc0,
	
    };
}
namespace Internal {
    enum Internal {
     
     Transform_INTERNAL_GetPosition = 0x2b61c48,
	 
	 Transform_INTERNAL_SetPosition = 0x2b61ce8,
	 
	 Component_GetTransform = 0x2ba38bc,
	 
    };
}
namespace Message {
    enum Message {
    // 
    U3DStr = 0x2c2acfc,
	
	CurrentUIScene = 0xab25e0,
	
	ShowDynamicPopupMessage = 0xa52f80,
	
	ShowPopupMessage = 0xa530c0,
	
	AddTeammateHud = 0xa6a5dc,
	
	U3DStrConcat = 0x2c29624,
		
    };
}

struct {

	uintptr_t MainCameraTransform = 0x6C;  // public Transform MainCameraTransform; // 0x54  [v1.60.2]
	uintptr_t Dictionary = 0x44; // protected Dictionary<byte, Player> NgEZJDq; // 0x44  [v1.60.2]
	/////////////--FOR ESP GRENADE & COLOR---//////////////////////
	uintptr_t GrenadeLine_isVisible = 0xC;
	uintptr_t GrenadeLine_m_GrenadeLine = 0x10; // protected LineRenderer m_GrenadeLine //0x10
	uintptr_t LineRenderer_Set_PositionCount = 0x2B37F10; // public void set_positionCount(int value) { }
	uintptr_t LineRenderer_SetPosition = 0x2B37FBC; // public void SetPosition(int index, Vector3 position) { }
	uintptr_t GrenadeLine_DrawLine = 0x115C53C; // private void DrawLine(Vector3 throwPos, Vector3 throwVel, Vector3 gravity) { } 0x19C0EC4
	uintptr_t GrenadeLine_Update = 0x115C1EC; // private void Update() { }
	uintptr_t Set_StartColor = 0x2B37D54; // public sealed class LineRenderer : Renderer : public void set_startColor(Color value) { }
	uintptr_t Set_EndColor = 0x2B37DF8; // public sealed class LineRenderer : Renderer : public void set_endColor(Color value) { }
	/////////////--FOR ESP AIMBOT & CANVAS---/////////////
	uintptr_t HeadTF = 0x1E8; // protected Transform JoqBDUR; // 0x1E8  [v1.60.2]
	uintptr_t HipTF = 0x1EC; // protected Transform gBb{jci; // 0x1EC  [v1.60.2]
	uintptr_t HandTF = 0x1E4; // protected Transform yFayxSS; // 0x1E4  [v1.60.2]
	uintptr_t LeftHandTF = 0x214; // protected Transform yvZ[NRv; // 0x214  [v1.60.2]
	uintptr_t EyeTF = 0x1F0; // protected Transform S~D]ly; // 0x1F0 [v1.60.2]
	uintptr_t ToeTF = 0x1FC; // protected Transform `}Klj; // 0x1FC  [v1.60.2]
	uintptr_t RightShoulder = 0x21C; // protected Transform IcoOWF; // 0x21C  [v1.60.2]
	uintptr_t LeftShoulder = 0x218; // protected Transform iuhFwSC; // 0x218  [v1.60.2]
	uintptr_t RightFoot = 0x210; // protected Transform lpF[hWQ; // 0x210  [v1.60.2]
	uintptr_t LeftFoot = 0x20C; // protected Transform oporBaB; // 0x20C  [v1.60.2]
	uintptr_t LeftLeg = 0x208; // protected Transform APPZcef; // 0x208  [v1.60.2]
	uintptr_t RightLeg = 0x204; // protected Transform jzgDN^; // 0x204  [v1.60.2]
	/////////////--PLAYER COORDINATES & CONFIGS---/////////
	uintptr_t IsClientBot = 0xF0; // public bool IsClientBot; // 0xC8  [v1.60.2]
	uintptr_t GetPhysXPose = 0x895F64; // public VCDxuoO GetPhysXPose() { } [v1.60.2]
	uintptr_t get_isAlive = 0x9007C0; // public bool IsCameraTrackableEntityAlive [v1.60.2]
	uintptr_t get_IsSighting = 0x88F168; // public bool get_IsSighting [v1.60.2]
	uintptr_t get_IsReallyDead = 0x8B035C; // public bool get_IsReallyDead [v1.60.2]
	uintptr_t get_isLocalPlayer = 0x8895D4; // public bool IsLocalPlayer [v1.60.2]
	uintptr_t get_isLocalTeam = 0x8B85F4; // public virtual bool IsLocalTeammate [v1.60.2]
	uintptr_t get_isVisible = 0x8B1AD8; // public override bool IsVisible [v1.60.2]
	uintptr_t IsSameTeam = 0x120A894; // protected override void OnUIInit() [v1.60.2]
	uintptr_t AttackableEntity_GetIsDead = 0xAC4594; // public bool get_IsDead() [v1.60.2]
	uintptr_t AttackableEntity_IsVisible = 0xACE4A0; // public virtual bool IsVisible() [v1.60.2]
	uintptr_t GetAttackableCenterWS = 0x8AEA78; // public override Vector3 GetAttackableCenterWS [v1.60.2]
	uintptr_t get_NickName = 0x8AEFDC; // public string get_NickName [v1.60.2]
	uintptr_t getPlayerByIndex = 0xB0130C; // public Player elpb[T(byte Ox|uy|) { } [v1.60.2]
	uintptr_t get_CurHP = 0x8E690C; // public int get_CurHP() { } [v1.60.2]
	uintptr_t get_MaxHP = 0x8E69E8; // public int get_MaxHP() { } 1.57
	uintptr_t get_PlayerID = 0x89A360; // public {QAb~u get_PlayerID() { } [v1.60.2]
	uintptr_t get_IsDieing = 0x88AC18; // public bool get_IsDieing() { } [v1.60.2]
	uintptr_t get_IsSkyDiving = 0x895C6C; // public bool get_IsSkyDiving() { } [v1.60.2]
	uintptr_t get_IsSkyDashing = 0x8B1328; // public bool get_IsSkyDashing() { } [v1.60.2]
	uintptr_t get_IsParachuting = 0x895C30; // public bool get_IsParachuting() { } [v1.60.2]
	uintptr_t IsVisible = 0x8B1AD8; // public override bool IsVisible() { } [v1.60.2]
	uintptr_t IsLocalPlayer = 0x8895D4; // public bool IsLocalPlayer() { } [v1.60.2]
	uintptr_t Transform_get_forward = 0x2B627A8;  // public Vector3 get_Forward() { } [v1.60.2]
	uintptr_t IsLocalTeammate = 0x8B85F4; // public virtual bool IsLocalTeammate() { } [v1.60.2]
	uintptr_t Current_Local_Player = 0xAB3450; // public static Player CurrentLocalPlayer [v1.60.2]
	uintptr_t GetLocalPlayerOrObServer = 0xAB3C84; // public static Player GetLocalPlayerOrObServer [v1.60.2]
	uintptr_t Player_Index = 0xB0130C; // public Player elpb[T(byte Ox|uy|) { } [v1.60.2]
	uintptr_t IsFiring = 0x88F11C; // public bool IsFiring [v1.60.2]
	uintptr_t IsCrouching = 0x88ABC0; // public bool IsCrouching [v1.60.2]
	uintptr_t GetHead = 0x8F3D54; // public virtual Transform GetHeadTF() { } [v1.60.2]
	uintptr_t GetHipTF = 0x8F3E50; // public virtual Transform GetHipTF() { } [v1.60.2]
	uintptr_t GetLocalPlayer = 0xD3800C; // private static Player GetLocalPlayer() { } [v1.60.2]
	uintptr_t GetLocalCar = 0x8B057C; // public Vehicle VehicleIAmIn() { }
	uintptr_t IsDriver = 0x8935B8; // public bool get_IsDriver() { }
	/////////////--ESP & AIMBOT CONFIGURATION---/////////
	uintptr_t Curent_Match = 0xAB312C; // public static `ZtmgF CurrentMatch() { } [v1.60.2]
	uintptr_t CurrentMatch = 0xAB312C; // public static `ZtmgF CurrentMatch() { } [v1.60.2]
	uintptr_t get_imo = 0x8AB8EC; // public ytMNhlw GetActiveWeapon() { } [v1.60.2]
	uintptr_t set_esp = 0x1302A60; // public void utKBmvc(Vector3 RvOJF{, Vector3 bQiMI) { } [v1.60.2]
	uintptr_t set_aim = 0x8AFE3C; // public void SetAimRotation(Quaternion laYChSW) { } [v1.60.2]
	uintptr_t Camera_main_fov = 0x2B9F47C; // public float get_fieldOfView [v1.60.2]
	uintptr_t Camera_main = 0x2BA19BC; // public static Camera get_main [v1.60.2]
	uintptr_t get_height = 0x2B572F8; // public static int get_height [v1.60.2]
	uintptr_t get_width = 0x2B57274; // public static int get_width [v1.60.2]
	uintptr_t set_height = 0x398E718; // public void set_height(float value) { } [v1.60.2]
	//uintptr_t WorldToScreenPoint = 0x29E7FD8; // public Vector3 WorldToScreenPoint(Vector3 position, Camera.MonoOrStereoscopicEye eye) { } [v1.60.2]
	//uintptr_t WorldToScreenPoint = 0x2BA12CC; // public Vector3 WorldToScreenPoint(Vector3 position) { } [v1.60.2]
	uintptr_t Transform_INTERNAL_GetPosition = 0x2B61C48; // private void INTERNAL_get_position [v1.60.2]
	uintptr_t Transform_INTERNAL_SetPosition = 0x2B61CE8; // private void INTERNAL_set_position [v1.60.2]
	uintptr_t Screen_get_width = 0x2B57274; // public static int get_width() { } [v1.60.2]
	uintptr_t Screen_get_height = 0x2B572F8; // public static int get_height() { } [v1.60.2]
	uintptr_t get_main = 0x2BA19BC; // public static Camera get_main() { } [v1.60.2]
	uintptr_t Component_get_transform = 0x2BA38BC; // public Transform get_transform() { } [v1.60.2]
	uintptr_t Transform_get_position = 0x2B61C48; // private void INTERNAL_get_position(out Vector3 value) { } [v1.60.2]
	/////////////--ESP ALERTS & OTHER OFFSETS---/////////
	uintptr_t U3DStr = 0x2C2ACFC; // private string CreateString(sbyte* value) { } [v1.60.2]
	uintptr_t CurrentUIScene = 0xAB25E0; // public static UICOWBaseScene CurrentUIScene [v1.60.2]
	uintptr_t spof_nick = 0x8AEFE4; // protected void m]^O~Mn(string IyxY|Aa) { } [v1.60.2]
	uintptr_t get_IsCrouching = 0x88ABC0; // public bool IsCrouching() { } [v1.60.2]
	uintptr_t String_Concat = 0x2C1BD94; // public static string Concat(string str0, string str1) { } [v1.60.2]
	uintptr_t ShowDynamicPopupMessage = 0xA52F80; // public void ShowDynamicPopupMessage(string message, float duration = 5) { } [v1.60.2]
	uintptr_t ShowPopupMessage = 0xA530C0; //	public void ShowPopupMessage(string message, float duration = 2) { } [v1.60.2]
	uintptr_t AddTeammateHud = 0xA6A5DC; // public void ShowAssistantText(string playerName, string line) { } [v1.60.2]
	uintptr_t U3DStrConcat = 0x2C29624; // public static string Concat(string str0, string str1, string str2, string str3) { } [v1.60.2]
	uintptr_t Component_GetTransform = 0x2BA38BC; // public Transform get_transform() [v1.60.2]
	uintptr_t GetCameraTrackableEntityTransfrom = 0x9007B8; // public Transform GetCameraTrackableEntityTransfrom [v1.60.2]
	uintptr_t GetForward = 0x2B627A8; // public Vector3 get_forward [v1.60.2]
	uintptr_t get_deltaTime = 0x2B60B74; // public static float get_fixedDeltaTime [v1.60.2]
	uintptr_t get_MyFollowCamera = 0x8AF6B8; // public FollowCamera get_MyFollowCamera() [v1.60.2]
	uintptr_t GetWeaponType = 0x8F8544; // public ytMNhlw.Utan}] GetWeaponType() { } [v1.60.2]
	/////////////--MEMORY PATCHES OFFSETS---/////////
	uintptr_t CameraView = 0x1083688; // public virtual float get_OffsetForNormal() { }
	uintptr_t Senstivity = 0x8E0854; // TYPE GG = 300.0F NEARBY VALUES, 0.00999999978F & UPPER -3.386859859e25F & UPPER -1.30454813e21F
	uintptr_t MedKitRunning = 0x18836E4; // private void OnPreparationCancel(object[] param) { } : INSIDE internal class UIHudPreparationTimerController : UIBaseController
	uintptr_t MedKitRunning2 = 0x8DB0C8; // public bool IsMoving() { } : NEARBY public virtual void UpdateKinematics(float }x[tOF, float OsUltaA) { }
	uintptr_t RemoveScope = 0x8EA924; // public virtual bool IsSightingUIAvailable() { } : NEARBY public b^T]gJ GetWeaponSightingAttachmentData() { }
	uintptr_t FireMovement = 0x8E1748; // public bool IsFreeMove() { } : NEARBY public void MountWeaponGameObject(ytMNhlw ~~gGPa) { }
	uintptr_t CarTeleport = 0x22B164C; // public static DQIdVHi ~W]PnD(Vector3 lyabLZX) { }
	uintptr_t MedKitFast = 0x12F2AA8; // public virtual float Ty|XLe[() { }
	uintptr_t AmmoFree = 0xD793B4; // public bool get_IsAmmoFree() { }

	uintptr_t BLKLST1 = 0x2B8EC5C;
	uintptr_t BLKLST2 = 0x1BF2450;
	uintptr_t ELIMINA = 0x8DF618;

	/////////////--MEMORY PATCHES LIBUNITY---/////////
	uintptr_t Night = 0x2CFF7C; // 1.0e-6F // UNITY BLIB
	uintptr_t SpeedRun = 0xD789A4;
	uintptr_t FastFW = 0x34165C; // 0.14177720249F // UNITY BLIB
	uintptr_t WallS1 = 0xAD7E68; // -8,388,395.5F // UNITY BLIB
	uintptr_t WallS2 = 0xAD7E78; // -8,388,393.5F // UNITY BLIB
	uintptr_t WallS3 = 0xAD7EA8; // -8,388,387.5F // UNITY BLIB

	/////////////--OFFSETS IS INACTIVE---/////////
	/*uintptr_t CurrentLocalSpectator = 0x11CD44C; // public static hxgtqc~ CurrentLocalSpectator() { } [v1.60.2]
	uintptr_t GetCharacterHeight = 0x823DEC; // public float GetCharacterHeight() [v1.60.2]
	uintptr_t SetAimRotation = 0x810F18; // public void SetAimRotation(Quaternion laYChSW) { } [v1.60.2]
	uintptr_t spof_uid = 0xE6721C; // protected void sWvUNu(ulong IyxY|Aa) { } [v1.60.2]
	uintptr_t set_invitee_nickname = 0x35F0AA4; // public void set_invitee_nickname(string value) { } [v1.60.2]
	uintptr_t get_CharacterController = 0x80CAA4; // public CharacterController get_CharacterController() [v1.60.2]
	uintptr_t IsUserControlChanged = 0x81B218; // public bool IsUserControlChanged() [v1.60.2]
	uintptr_t Raycast = 0x35E89E0; // public static bool Raycast(Vector3 origin, Vector3 direction, float maxDistance, int layerMask) { } [v1.60.2]
	uintptr_t GetCharacterControllerTopPosition = 0x855254; // public virtual Vector3 GetCharacterControllerTopPosition [v1.60.2]
	uintptr_t GetLocalPlayer2 = 0x9EA604; // public Player hszKW]() { } [v1.60.2]
	uintptr_t Camera_WorldToScreenPoint = 0x27F7F90; // public Vector3 WorldToScreenPoint(Vector3 position) [v1.60.2]*/

	uintptr_t il2cpp_string_new = 0x2E2CE0C; // 1.53.2

} Global;
#endif



