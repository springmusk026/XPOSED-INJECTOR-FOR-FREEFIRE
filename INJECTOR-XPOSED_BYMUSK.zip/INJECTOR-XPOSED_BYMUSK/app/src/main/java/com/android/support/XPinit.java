package com.android.support;

import android.content.Context;

import java.io.IOException;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class XPinit implements IXposedHookLoadPackage {
    public static final String TAG = "Musk inject";
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("com.dts.freefireth"))
            return;

        XposedBridge.log(TAG +  " " + lpparam.packageName);

        try {
            System.load("/data/local/tmp/libserver.so");
            XposedBridge.log(TAG + " Congrats Lib Loader");
        }catch (Exception e){
            e.printStackTrace();
        }
    }


}

