package com.android.support;

import android.app.Application;
import eu.chainfire.libsuperuser.Shell;
import java.io.IOException;

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            Runtime.getRuntime().exec("su");
			Shell.SU.run("setenforce 0");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
