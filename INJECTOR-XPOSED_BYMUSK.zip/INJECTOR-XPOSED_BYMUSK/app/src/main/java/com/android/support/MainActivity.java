package com.android.support;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.widget.Toast;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import eu.chainfire.libsuperuser.Shell;

public class MainActivity extends Activity {
	private static RandomAccessFile raf;
	
   
    //Load lib
    static {
        // When you change the lib name, change also on Android.mk file
        // Both must have same name
        System.loadLibrary("Client");
    }

    //To call onCreate, please refer to README.md
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
       Start(this);

  
    }

    public static void Start(final Context context) {
		try {
			raf = new RandomAccessFile("/storage/emulated/0/musk", "rw");
		} catch (FileNotFoundException e) {
			Toast.makeText(context, "Cant Access !", Toast.LENGTH_LONG).show();

		} 
		try {
			String payload_source = context.getApplicationInfo().nativeLibraryDir + File.separator + "libserver.so";

			String payload_dest = "/data/local/tmp/libserver.so";

			Shell.Pool.SU.run(new String[] {"cp " + payload_source + " " + payload_dest, "chmod 777 " + payload_dest});



		} catch (Exception e) {

		}
        //Check if overlay permission is enabled or not
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            Toast.makeText(context.getApplicationContext(), "Overlay permission is required in order to show mod menu. Restart the game after you allow permission", Toast.LENGTH_LONG).show();
            Toast.makeText(context.getApplicationContext(), "Overlay permission is required in order to show mod menu. Restart the game after you allow permission", Toast.LENGTH_LONG).show();
            context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION",
                    Uri.parse("package:" + context.getPackageName())));
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    System.exit(1);
                }
            }, 5000);
            return;
        } else {
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    context.startService(new Intent(context, Menu.class));
                }
            }, 500);
        }
    }
}
